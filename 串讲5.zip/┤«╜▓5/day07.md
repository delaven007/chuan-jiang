## 神经网络的实现过程

http://playground.tensorflow.org

1、准备数据集，提取特征，作为输入喂给神经网络（ Neural Network NN)

2、搭建 NN 结构，从输入到输出（先搭建计算图，再用会话执行）
				 （NN 前向传播算法 ---->计算输出）

3、大量特征数据喂给 NN ，迭代优化 NN 参数
					(NN 反向传播算法 ---->优化参数训练模型)

4、使用训练好的模型预测和分类

<img src="images/1569293949910.png" alt="1569293949910" style="zoom:73%;" />

## 前向传播

前向传播是指对神经网络沿着从输入层到输出层的顺序，依次计算并存储模型的中间变量（包括输出）。

计算神经网络的前向传播结果需要三部分信息，神经网络的输入、神经网络的结构以及权重参数。

第一个部分是**神经网络的输入**，这个输入就是从数据集中提取的特征向量。比如在图中有两个输入， 一个是零件的长度x1，一个是零件的质量x2 。

![1563532632881](images/1563532632881.png)



第二个部分为**神经网络的连接结构**。神经网络是由神经元构成的，神经网络的结构给出不同神经元之间输入输出的连接关系。神经网络中的神经元也可以称之为**节点**。在图中，有一个隐藏层，三个隐藏单元，eg，a11 节点有两个输入，他们分别是X1 和X2 的输出。而a11 的输出则是节点y 的输入。

第三个部分是**每个神经元中的参数**。在图中用W 来表示神经元中的参数。W 的上标表明了神经网络的层数，比如以 $w^{(1)}$ 表示第一层节点的参数，而以 $w^{(2)}$ 表示第二层节点的参数。W 的下标表明了连接节点编号，比如 $w^{(1)}_{1,2}$ 表示连接 $x_1$ 和 $a_{12}$ 节点的边上的权重。

如给定神经网络的输入、神经网络的结构以及边上权重，就可以通过前向传播算法来计算出神经网络的输出。



下图展示了这个神经网络前向传播的过程。

![1563534410039](images/1563534410039.png)

上图给出了输入层的取值x1 =0 .7 和X2=0.9 。从输入层开始一层一层地使用向前传播算法。首先隐藏层中有三个节点， 每一个节点的取值都是输入层取值的加权和。下面给出了a 11 取值的详细计算过程：
![1563534454597](images/1563534454597.png)

a12 和a13 也可以通过类似的方法计算得到，图中也给出了具体的计算公式。在得到第一层节点的取值之后，可以进一步推导得到输出层的取值。类似地，输出层中节点的取值就是第一层的加权和：

![1563534540646](images/1563534540646.png)

因为这个输出值大于阈值0，所以在这个样例中最后给出的答案是：这个产品是合格的。这就是整个前向传播的算法。前向传播算法可以表示为矩阵乘法。将输入X1,X2 组织成一个 1× 2 的矩阵x=[x1,x2 ］ ，而w1组织成一个2 × 3 的矩阵：

![1563591146273](images/1563591146273.png)

这样通过矩阵乘法可以得到隐藏层三个节点所组成的向量取值：

![1563591267110](images/1563591267110.png)

类似的输出层可以表示为：

![1563591289247](images/1563591289247.png)

```python
import numpy as np

x =[0.7,0.9]

W1=[[0.2,0.1,0.4],
    [0.3,-0.5,0.2]]
W2=[0.6,0.1,-0.2]

a= np.dot(x,W1)
y=np.dot(a,W2)

print(a)
print(y)

[ 0.41 -0.38  0.46]
0.11599999999999996
```



```python
import tensorflow as tf

x =tf.placeholder(tf.float32, shape=(None,2))

w1=tf.Variable(tf.random_normal([2,3],stddev=1,seed=1))
w2=tf.Variable(tf.random_normal([3,1],stddev=1,seed=1))

a= tf.matmul(x,w1)
y= tf.matmul(a,w2)
```

### 前向传播过程 的 tensorflow 描述

变量初始化、计算图节点运算都要用会话（ with 结构）实现

```python 
with tf.Session() as sess:
    sess.run(y)
```

变量初始化：在 sess.run 函数中用 tf.global_variables_initializer() 来初始化所有待优化变量。

```python
init_op = tf.global_variables_initializer()
sess.run(init_op)
```

计算图节点运算：在sess.run函数中写入待运算的节点

```python
sess.run(y)
```

用 tf.placeholder（）占位，在 sess.run 函数中用 feed_dict（）喂数据

```python
#喂一组数据：
x = tf.placeholder(tf.float32, shape=(1, 2))
sess.run(y, feed_dict={x: [[0.5,0.6]]})
#喂多组数据：
x = tf.placeholder(tf.float32, shape=(None, 2))
sess.run(y, feed_dict={x: [[0.1,0.2],[0.2,0.3],[0.3,0.4],[0.4,0.5]]})
```



## 反向传播

反向传播 ：训练模型参数 ，对所有参数使用梯度下降或其他算法，使得神经网络模型在训练数据上的损失函数最小。

### 损失函数

损失函数，也叫代价函数，评价模型对样本拟合度，预测结果与实际值越接近，说明模型的拟合能力越强，对应损失函数的结果就越小；反之，损失函数的结果越大。损失函数比较大时，对应的梯度下降比较快。为了计算方便，可以采用欧式距离作损失度量标准，通过最小化实际值与估计值之间的均方误差作为损失函数，即最小平方误差准则(MSE)。

损失函数的计算有很多方法。合适的损失函数能够确保深度学习模型更好地收敛，常见的损失函数有Softmax、欧式损失、sigmoid交叉熵损失、Triplet Loss、Moon Loss、Contrastive Loss等。

#### 解决回归问题的损失函数：均方误差MSE

![1563865732862](images/1563865732862.png)



用tensorflow 函数表示为loss_mse = tf.reduce_mean(tf.square(y_ - y))

反向传播训练方法： 以减小 loss 值为优化目标 ，有梯度下降 、 momentum优化器 、 adam优化器等优化方法。

这三种优化方法用tensorflow 的函数可以表示为：

```python
train_step=tf.train.GradientDescentOptimizer(learning_rate).minimize(loss)

train_step=tf.train.MomentumOptimizer(learning_rate,momentum).minimize(loss)

train_step=tf.train.AdamOptimizer(learning_rate).minimize(loss)
```

学习率 learning_rate： 决定每次参数更新的幅度。
优化器中都需要一个叫做学习率的参数，使用时如果学习率选择过大会导致待优化的参数在最小值附近波动不收敛的情况，如果学习率选择过小，会出现收敛速度慢的情况。 我们可以选个比较小的值填入， 比如 0.01 、 0.001。

1. tf.train.GradientDescentOptimizer 使用随机梯度下降算法，使参数沿着
   梯度的反方向，即总损失减小的方向移动，实现更新参数。

   其中，𝐽(𝜃)为损失函数， 𝜃为参数， 𝛼为学习率。

   ![1563866296204](images/1563866296204.png)

2. tf.train.MomentumOptimizer 在更新参数时，利用了超参数，参数更新公式是

   其中，𝛼为学习率，超参数为𝛽， 𝜃为参数， 𝑔(𝜃𝑖−1)为损失函数的梯度 。

   ![1563866483355](images/1563866483355.png)

3. tf.train.AdamOptimizer 是利用自适应学习率的优化算法， Adam 算法和随机梯度下降算法不同。随机梯度下降算法保持单一的学习率更新所有的参数，学习率在训练过程中并不会改变。而 Adam 算法通过计算梯度的一阶矩估计和二阶矩估计而为不同的参数设计独立的自适应性学习率。

#### 解决分类问题的损失函数：交叉熵（ cross entropy ）

交叉熵刻画了两个概率分布之间的距离， 它是分类问题中使用比较广的一种损失函数。

假设有两个分布p，q，则它们在给定样本集上的交叉熵定义如下： 
$$
CE(p,q)=−\sum_{x}p(x)logq(x)
$$

------

用Tensorflow 函数表示为 

```python
ce=-tf.reduce_sum(p * tf.log(tf.clip_by_value(q, 1e-12, 1.0))) 
```

（1e-12 是为了防止log0出现）

交叉熵越大，两个概率分布距离越远， 两个概率分布越相异 ;

交叉熵越小，两个概率分布距离越近 ，两个概率分布越相似 。

## 神经网络计算过程：

1. 导入模块，生成模拟数据集；
   import
   常量定义
   生成数据集

2. 前向传播：定义输入、参数和输出
   x=              y_ =
   w1=           w2=
   a=              y=

3. 反向传播：定义损失函数、反向传播方法
   loss=
   train_step=

4. 生成会话，训练 STEPS 轮

   ```python
   with tf.session() as sess
       Init_op=tf. global_variables_init ializer()
       sess_run(init_op)
       STEPS=3000
       for i in range(STEPS):
           start=
           end=
           sess.run(train_step, feed_dict:)
   ```

## 神经网络效果评价

用于分类的模型评价以准确率(Accuracy)、精确率(Precision)、召回率(Recall)、F1分值(F1 Score)为主，辅以ROC、AUC并结合实际应用进行结果评价

如果神经网络用于聚类，数据源并没有进行标记，那么其模型结果的评价按照聚类算法的标准来操作，如RMSSTD、R Square、SRP等

