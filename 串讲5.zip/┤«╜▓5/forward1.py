import numpy as np
x =[0.7,0.9]
W1=[[0.2,0.1,0.4],
    [0.3,-0.5,0.2]]
W2=[0.6,0.1,-0.2]

a= np.dot(x,W1)
y=np.dot(a,W2)

print(a)
print(y)


